export function ciudades(data) {
  console.log("swichhh", data);
  switch (data) {
    case "CENTENARIO_":
      data = "centenario";
      break;
    case "NEUQU?N_":
      data = "NEUQUÉN";
      break;
    case "GENERAL_FERN?NDEZ_ORO_":
      data = "GENERAL FERNANDEZ ORO";
      break;
    case "CIPOLLETTI_":
      data = "CIPOLLETTI";
      break;
    case "PASO_AGUERRE_":
      data = "PASO AGUERRE";
      break;
    case "PLOTTIER_":
      data = "PLOTTIER";
      break;
    case "SAN_MART?N_DE_LOS_ANDES":
      data = "SAN MARTÍN DE LOS ANDES";
      break;
    case "JUN?N_DE_LOS_ANDES":
      data = "JUNIN DE LOS ANDES";
      break;
    case "CHOS_MALAL_":
      data = "CHOS MALAL";
      break;
    case "ZAPALA_":
      data = "ZAPALA";
      break;
    case "CAVIAHUE_COPAHUE_":
      data = "CAVIAHUE_COPAHUE";
      break;
    case "PLAZA_HUINCUL_":
      data = "PLAZA HUINCUL";
      break;
    case "RINC?N_DE_LOS_SAUCES_":
      data = "RINCON DE LOS SAUCES";
      break;
    case "CUTRAL-CO_":
      data = "CUTRAL CO";
      break;
    case "SENILLOSA_":
      data = "SENILLOSA";
      break;
    case "SAN_PATRICIO_DEL_CHA?AR_":
      data = "SAN PATRICIO DEL CHAÑAR";
      break;
    case "ALUMIN?":
      data = "ALUMINÉ";
      break;
    case "BARRANCAS_":
      data = "BARRACAS";
      break;
    case "BUTA_RANQUIL_":
      data = "BUTA RANQUIL";
      break;
    case "EL_CHOC?N_":
      data = "EL CHOCON";
      break;
    case "EL_CHOLAR_":
      data = "EL CHOLAR";
      break;
    case "EL_HUEC?_":
      data = "EL HUECU";
      break;
    case "EL_SAUCE_":
      data = "EL SAUCE ";
      break;
    case "LAS_LAJAS_":
      data = "LAS LAJAS";
      break;
    case "LAS_OVEJAS_":
      data = "LAS OVEJAS";
      break;
    case "LONCOPU?":
      data = "LONCOPHUÉ";
      break;
    case "PIC?N_LEUF?_":
      data = "PICÚN LEUFÚ";
      break;
    case "SANTO_TOM?S_?":
      data = "SANTO TOMAS";
      break;
    case "TRICAO_MALAL_":
      data = "TRICAO MALAL";
      break;
    case "VILLA_EL_CHOC?N_?":
      data = "VILLA EL CHOCON";
      break;
    case "VILLA_LA_ANGOSTURA":
      data = "VILLA LA ANGOSTURA";
      break;
    case "VILLA_PEHUENIA":
      data = "VILLA PEHUENIA";
      break;
    case "VILLA_TRAFUL_":
      data = "VILLA TRAFUL";
      break;
    case "VISTA_ALEGRE_":
      data = "VISTA ALEGRE";
      break;
    case "PIEDRA_DEL_?GUILA_":
      data = "PIEDRA DEL ÁGUILA";
      break;
    case "VILLA_REGINA_":
      data = "VILLA REGINA";
      break;
    case "GENERAL_ROCA_":
      data = "GENERAL ROCA";
      break;
    case "SAN_CARLOS_DE_BARILOCHE_":
      data = "SAN CARLOS DE BARILOCHE";
      break;
    case "CATRIEL_":
      data = "CATRIEL";
      break;
    case "ALLEN_":
      data = "ALLEN";
      break;
    case "DINA_HUAPI_":
      data = "DINA HUAPI";
      break;
    case "LAS_PERLAS_":
      data = "LAS PERLAS";
      break;
    case "CINCO_SALTOS_":
      data = "CINCO SALTOS";
      break;
    case "CATRIEL_":
      data = "CATRIEL";
      break;
    case "BARDA_DEL_MEDIO_":
      data = "BARDA DEL MEDIO";
      break;
    case "CONTRALMIRANTE_CORDERO_":
      data = "CONTRAALMIRANTE CORDERO";
      break;
    case "EL_BOLS?N_":
      data = "EL BOLSÓN";
      break;
    case "LAMARQUE_":
      data = "LA MARQUE";
      break;
    case "LAS_GRUTAS_":
      data = "LAS GRUTAS";
      break;
    case "PASO_FLORES_":
      data = "PASO FLORES";
      break;
    case "PILCANIYEU_":
      data = "PILCANIYEU";
      break;
    case "POMONA_":
      data = "POMONA";
      break;
    case "SAN_ANTONIO_OESTE_":
      data = "SAN ANTONIO OSTE";
      break;
    case "VALCHETA_":
      data = "VALCHETA";
      break;
    case "VIEDMA_":
      data = "VIEDMA";
      break;
    case "VILLA_MANZANO_":
      data = "VILLA MANZANO";
      break;
    default:
      break;
  }
  return data;
}

export function provincias(data) {}
