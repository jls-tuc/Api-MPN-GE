export const getNro = (nro) => {
  return nro + 1;
};
